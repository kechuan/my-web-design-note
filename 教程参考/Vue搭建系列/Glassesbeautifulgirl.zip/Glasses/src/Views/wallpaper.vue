<template lang="">
    <div class="main-container">
        <div class="main-header">
            <a class="menu-link-main" href="#">二次元</a>
            <div class="header-menu">
                <a class="main-header-link" href="#">专辑</a>
                <a class="main-header-link" href="#">排行榜</a>
                <a class="main-header-link" href="#">歌手</a>
                <a class="main-header-link" href="#">分类</a>

            </div>
        </div>
        <div class="content-wrapper">
            还没开发
        </div>

    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>